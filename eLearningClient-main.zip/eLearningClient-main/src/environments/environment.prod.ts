export const environment = {
  production: true,
  baseUri: 'https://fintechedu.in/api/',
  baseLoginUri: 'https://fintechedu.in/api/'
};
