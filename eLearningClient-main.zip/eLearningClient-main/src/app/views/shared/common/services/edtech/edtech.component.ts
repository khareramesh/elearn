import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edtech',
  templateUrl: './edtech.component.html',
  styleUrls: ['./edtech.component.scss']
})
export class EdtechComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
