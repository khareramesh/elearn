import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technology-training',
  templateUrl: './technology-training.component.html',
  styleUrls: ['./technology-training.component.scss']
})
export class TechnologyTrainingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
