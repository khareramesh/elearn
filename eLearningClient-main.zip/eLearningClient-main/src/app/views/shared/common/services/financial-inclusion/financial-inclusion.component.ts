import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-financial-inclusion',
  templateUrl: './financial-inclusion.component.html',
  styleUrls: ['./financial-inclusion.component.scss']
})
export class FinancialInclusionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
