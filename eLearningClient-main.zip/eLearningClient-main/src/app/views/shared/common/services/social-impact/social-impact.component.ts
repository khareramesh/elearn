import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-social-impact',
  templateUrl: './social-impact.component.html',
  styleUrls: ['./social-impact.component.scss']
})
export class SocialImpactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
