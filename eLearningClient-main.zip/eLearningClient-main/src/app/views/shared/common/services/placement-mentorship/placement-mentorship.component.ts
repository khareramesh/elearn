import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-placement-mentorship',
  templateUrl: './placement-mentorship.component.html',
  styleUrls: ['./placement-mentorship.component.scss']
})
export class PlacementMentorshipComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
