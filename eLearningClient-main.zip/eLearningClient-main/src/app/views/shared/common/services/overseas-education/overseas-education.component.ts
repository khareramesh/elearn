import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-overseas-education',
  templateUrl: './overseas-education.component.html',
  styleUrls: ['./overseas-education.component.scss']
})
export class OverseasEducationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
