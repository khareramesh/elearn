import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feature-course-main',
  templateUrl: './feature-course-main.component.html',
  styleUrls: ['./feature-course-main.component.scss']
})
export class FeatureCourseMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
