export class Course{
    courseId: number;
    courseName: string;
    description: string;
    courseImg: ImageBitmap;
    examId: number;
    geographyId: number;
    status: number;
    regDate: Date;
    modDate: Date;
}